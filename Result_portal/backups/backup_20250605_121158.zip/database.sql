-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
-- Host: localhost    Database: student_result_portal
-- ------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


--
-- Table structure for table `alembic_version`
--

CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `alembic_version`
--

INSERT INTO `alembic_version` (`version_num`) VALUES ('059b4a62f47a');


--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_id` int NOT NULL,
  `action` varchar(100) NOT NULL,
  `target_type` varchar(50) DEFAULT NULL,
  `target_id` int DEFAULT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  `details` text,
  PRIMARY KEY (`id`),
  KEY `admin_id` (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=189 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (1, 2, 'Add Course', 'Course', 3, '2025-05-09 04:51:49', 'Added course Logical Thinking (BPS78)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (2, 2, 'Add Course', 'Course', 4, '2025-05-09 04:52:17', 'Added course AI learning (BNT65)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (3, 2, 'Enter Result', 'Result', 2, '2025-05-09 04:53:12', 'Entered result for student BPS0001827, course BNT65');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (4, 2, 'Enter Result', 'Result', 3, '2025-05-09 04:54:45', 'Entered result for student BPS0001827, course BPS78');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (5, 2, 'Enter Result', 'Result', 4, '2025-05-09 04:55:19', 'Entered result for student BIT0001927, course BPS78');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (6, 2, 'Broadcast Notification', 'Student', NULL, '2025-05-09 05:13:41', 'Broadcasted notification to 3 students');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (7, 2, 'Broadcast Notification', 'Student', NULL, '2025-05-09 05:22:22', 'Broadcasted notification to 3 students');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (8, 2, 'Broadcast Notification', 'Student', NULL, '2025-05-09 05:25:57', 'Broadcasted notification to 3 students');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (9, 2, 'Enter Result', 'Result', 5, '2025-05-09 05:58:30', 'Entered result for student BIT0001927, course BIT0067');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (10, 2, 'Enter Result', 'Result', 6, '2025-05-09 06:11:34', 'Entered result for student BIT0001927, course BIT0067');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (11, 2, 'Edit Result', 'Result', 6, '2025-05-09 06:13:14', 'Edited result for student BIT0001927, course BIT0067');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (12, 2, 'Reset Password', 'Student', 2, '2025-05-09 06:44:15', 'Reset password for Joseph (BNS002)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (13, 2, 'Archive Student', 'Student', 1, '2025-05-11 05:00:40', 'Archived student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (14, 2, 'Add Course', 'Course', 5, '2025-05-11 07:49:49', 'Added course fgf (vdr4t4) to program BNS');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (15, 2, 'Delete Course', 'Course', 5, '2025-05-11 07:50:01', 'Deleted course fgf (vdr4t4)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (16, 2, 'Delete Course', 'Course', 2, '2025-05-11 08:47:06', 'Deleted course Python programming (BIT0067)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (17, 2, 'Delete Course', 'Course', 3, '2025-05-11 08:47:12', 'Deleted course Logical Thinking (BPS78)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (18, 2, 'Delete Course', 'Course', 4, '2025-05-11 08:47:15', 'Deleted course AI learning (BNT65)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (19, 2, 'Add Course', 'Course', 6, '2025-05-11 08:48:28', 'Added course Python programming (BIT0067) to program BIT');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (20, 2, 'Add Course', 'Course', 7, '2025-05-11 08:48:44', 'Added course Logical Thinking (BPS78) to program BNS');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (21, 2, 'Enter Result', 'Result', 1, '2025-05-11 08:54:22', 'Entered result for student BPS0001827, course BIT0067');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (22, 2, 'Enter Result', 'Result', 2, '2025-05-11 08:55:11', 'Entered result for student BIT0001927, course BIT0067');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (23, 2, 'Enter Result', 'Result', 3, '2025-05-11 08:55:36', 'Entered result for student BIT0001927, course BPS78');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (24, 2, 'Delete Course', 'Course', 6, '2025-05-15 11:57:53', 'Deleted course Python programming (BIT0067)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (25, 2, 'Add Course', 'Course', 8, '2025-05-15 12:25:28', 'Added course Python programming (BIT0067) to program BIT');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (26, 2, 'Send Notification', 'Student', 4, '2025-05-15 12:54:31', 'Sent notification to Agyenkwa Arthur  (BIT0001227)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (27, 2, 'Enter Result', 'Result', 1, '2025-05-15 17:23:23', 'Entered result for student BIT0001927, course BIT0067');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (28, 2, 'Enter Result', 'Result', 2, '2025-05-15 17:24:03', 'Entered result for student BIT0001927, course BPS78');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (29, 2, 'Enter Result', 'Result', 3, '2025-05-15 17:24:26', 'Entered result for student BIT0001927, course BIT0067');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (30, 2, 'Enter Result', 'Result', 4, '2025-05-15 17:24:56', 'Entered result for student BIT0001927, course BPS78');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (31, 2, 'Edit Student', 'Student', 1, '2025-05-15 21:01:05', 'Edited student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (32, 2, 'Add Course', 'Course', 9, '2025-05-15 23:16:11', 'Added course IT PROJECT MANAGEMENT (BINT 302) to program BIT');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (33, 2, 'Add Course', 'Course', 10, '2025-05-15 23:17:36', 'Added course DATABASE SYSTEMS II (BINT 304) to program BIT');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (34, 2, 'Add Course', 'Course', 11, '2025-05-15 23:18:34', 'Added course DATA COMMUNICATION & COMPUTER NETWORKS II (BINT 306) to program BIT');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (35, 2, 'Add Course', 'Course', 12, '2025-05-15 23:19:25', 'Added course RESEARCH METHODS (BINT 307) to program BIT');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (36, 2, 'Enter Result', 'Result', 5, '2025-05-16 00:42:45', 'Entered result for student BPS0001827, course BINT 302');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (37, 2, 'Edit Student', 'Student', 3, '2025-05-17 16:26:10', 'Edited student Micheal Ohene Asante (BPS0001827)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (38, 2, 'Edit Student', 'Student', 3, '2025-05-17 16:26:23', 'Edited student Micheal Ohene Asante (BPS0001827)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (39, 2, 'Edit Student', 'Student', 3, '2025-05-17 16:26:29', 'Edited student Micheal Ohene Asante (BPS0001827)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (40, 2, 'Edit Student', 'Student', 1, '2025-05-17 16:26:41', 'Edited student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (41, 2, 'Edit Student', 'Student', 4, '2025-05-17 16:26:49', 'Edited student Agyenkwa Arthur  (BIT0001227)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (42, 2, 'Edit Student', 'Student', 1, '2025-05-17 17:31:39', 'Edited student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (43, 2, 'Edit Student', 'Student', 1, '2025-05-17 17:40:54', 'Edited student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (44, 2, 'Edit Student', 'Student', 1, '2025-05-17 17:41:19', 'Edited student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (45, 2, 'Edit Student', 'Student', 1, '2025-05-17 17:56:51', 'Edited student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (46, 2, 'Edit Student', 'Student', 1, '2025-05-17 18:01:11', 'Edited student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (47, 2, 'Edit Student', 'Student', 1, '2025-05-17 18:17:18', 'Edited student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (48, 2, 'Archive Student', 'Student', 1, '2025-05-17 22:54:04', 'Archived student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (49, 2, 'Edit Student', 'Student', 1, '2025-05-27 22:55:26', 'Edited student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (50, 2, 'Edit Student', 'Student', 1, '2025-05-27 22:58:58', 'Edited student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (51, 2, 'Edit Student', 'Student', 1, '2025-05-28 00:03:38', 'Edited student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (52, 2, 'Create Result', 'Result', NULL, '2025-05-28 00:11:13', 'Created result for student ID 1, course ID 8');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (53, 2, 'Create Result', 'Result', NULL, '2025-05-28 00:11:33', 'Created result for student ID 1, course ID 9');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (54, 2, 'Create Result', 'Result', NULL, '2025-05-28 00:11:57', 'Created result for student ID 1, course ID 10');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (55, 2, 'Create Result', 'Result', NULL, '2025-05-28 00:12:24', 'Created result for student ID 1, course ID 11');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (56, 2, 'Edit Student', 'Student', 1, '2025-05-28 00:12:38', 'Edited student Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (57, 2, 'Create Result', 'Result', NULL, '2025-05-28 00:13:02', 'Created result for student ID 1, course ID 12');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (58, 2, 'Archive Student', 'Student', 4, '2025-05-28 01:34:32', 'Archived student Agyenkwa Arthur  (BIT0001227)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (59, 2, 'Archive Student', 'Student', 3, '2025-05-28 01:58:24', 'Archived student Micheal Ohene Asante (BPS0001827)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (60, 2, 'Send Notification', 'Student', 1, '2025-05-28 03:04:45', 'Sent notification to Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (61, 2, 'Broadcast Notification', 'Student', NULL, '2025-05-28 03:45:15', 'Broadcasted notification to 3 students');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (62, 2, 'Broadcast Notification', 'Student', NULL, '2025-05-28 03:53:18', 'Broadcasted notification to 3 students');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (63, 2, 'Send Notification', 'Student', 1, '2025-05-28 03:57:00', 'Sent notification to Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (64, 2, 'Archive Student', 'Student', 3, '2025-05-28 10:27:05', 'Archived student Micheal Ohene Asante (BPS0001827)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (65, 2, 'Send Notification', 'Student', 1, '2025-05-28 10:42:15', 'Sent notification to Max Grip (BIT0001927)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (66, 2, 'Add Student', 'Student', NULL, '2025-05-28 22:03:37', 'Added student Joyce Elli (BIT0005626) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (67, 2, 'Reset Password', 'Student', 5, '2025-05-28 22:04:07', 'Reset password for Joyce Elli (BIT0005626)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (68, 2, 'Reset Password', 'Student', 5, '2025-05-28 22:10:14', 'Reset password for Joyce Elli (BIT0005626)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (69, 2, 'Add Student', 'Student', NULL, '2025-05-29 18:53:08', 'Added student  Marylyn Grip (BIT0004527) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (70, 2, 'Add Student', 'Student', NULL, '2025-05-29 19:08:21', 'Added student Maryln Grip (BIT0008926) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (71, 2, 'Delete Student', 'Student', 7, '2025-05-29 19:09:56', 'Deleted student Maryln Grip (BIT0008926)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (72, 2, 'Add Student', 'Student', NULL, '2025-05-29 19:11:03', 'Added student Maryln Grip (BIT0002526) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (73, 2, 'Archive Student', 'Student', 8, '2025-05-29 19:24:33', 'Archived student Maryln Grip (BIT0002526)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (74, 2, 'Delete Student', 'Student', 8, '2025-05-29 19:24:40', 'Deleted student Maryln Grip (BIT0002526)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (75, 2, 'Add Student', 'Student', NULL, '2025-05-29 19:25:42', 'Added student Maryln Grip (BIT0009826) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (76, 2, 'Delete Student', 'Student', 9, '2025-05-29 19:34:35', 'Deleted student Maryln Grip (BIT0009826)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (77, 2, 'Add Student', 'Student', NULL, '2025-05-29 19:35:40', 'Added student Maryln Grip (BIT0001426) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (78, 2, 'Archive Student', 'Student', 10, '2025-05-29 19:44:09', 'Archived student Maryln Grip (BIT0001426)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (79, 2, 'Delete Student', 'Student', 10, '2025-05-29 19:44:17', 'Deleted student Maryln Grip (BIT0001426)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (80, 2, 'Add Student', 'Student', NULL, '2025-05-29 19:45:16', 'Added student Maryln Grip (BIT0009026) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (81, 2, 'Add Student', 'Student', NULL, '2025-05-29 19:48:29', 'Added student Maryln Grip (BIT0009026) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (82, 2, 'Delete Student', 'Student', 12, '2025-05-29 19:49:29', 'Deleted student Maryln Grip (BIT0009026)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (83, 2, 'Add Student', 'Student', NULL, '2025-05-29 19:50:51', 'Added student Maryln Grip (BIT0004526) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (84, 2, 'Delete Student', 'Student', 13, '2025-05-29 19:51:36', 'Deleted student Maryln Grip (BIT0004526)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (85, 2, 'Add Student', 'Student', NULL, '2025-05-29 19:53:18', 'Added student Maryln Grip (BIT0004526) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (86, 20, 'Password Changed', 'User', 20, '2025-05-29 19:54:44', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (87, 2, 'Create Result', 'Result', NULL, '2025-05-29 19:56:51', 'Created result for student ID 14, course ID 8');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (88, 2, 'Create Result', 'Result', NULL, '2025-05-29 19:57:31', 'Created result for student ID 14, course ID 9');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (89, 2, 'Edit Student', 'Student', 14, '2025-05-29 19:58:50', 'Edited student Maryln Grip (BIT0004526)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (90, 2, 'Create Result', 'Result', NULL, '2025-05-29 19:59:19', 'Created result for student ID 14, course ID 10');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (91, 2, 'Reset Password', 'Student', 14, '2025-05-29 20:01:02', 'Reset password for Maryln Grip (BIT0004526)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (92, 2, 'Add Course', 'Course', 13, '2025-05-29 20:43:12', 'Added course Human Computer Interaction (BHCI 344) to program Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (93, 2, 'Archive Student', 'Student', 5, '2025-05-29 21:12:39', 'Archived student Joyce Elli (BIT0005626)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (94, 2, 'Add Course', 'Course', 14, '2025-05-29 22:53:00', 'Added course Introduction To Computer Science (CS101) to program Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (95, 2, 'Add Course', 'Course', 15, '2025-05-29 22:55:54', 'Added course Introduction To Computer Science (CSC101) to program Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (96, 2, 'Delete Course', 'Course', 14, '2025-05-29 22:58:32', 'Deleted course Introduction To Computer Science (CS101)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (97, 2, 'Delete Course', 'Course', 15, '2025-05-29 23:37:33', 'Deleted course Introduction To Computer Science (CSC101)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (98, 2, 'Add Course', 'Course', 16, '2025-05-29 23:47:03', 'Added course Introduction To Computer Science (CSC101) to program Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (99, 2, 'Edit Course', 'Course', 16, '2025-05-30 00:08:46', 'Edited course Introduction To Computer Science (CSC101)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (100, 2, 'Backup', 'System', NULL, '2025-05-30 02:02:16', 'Created backup: backup_20250530_020214.zip');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (101, 2, 'Backup', 'System', NULL, '2025-05-30 02:05:04', 'Created backup: backup_20250530_020454.zip');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (102, 2, 'Delete Backup', 'System', NULL, '2025-05-30 13:38:43', 'Deleted backup: backup_20250530_020214.zip');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (103, 2, 'Delete Backup', 'System', NULL, '2025-05-30 13:44:52', 'Deleted backup: backup_20250530_020454.zip');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (104, 2, 'Backup', 'System', NULL, '2025-05-30 13:47:46', 'Created backup: backup_20250530_134745.zip');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (105, 2, 'Delete Backup', 'System', NULL, '2025-05-30 13:59:06', 'Deleted backup: backup_20250530_134745.zip');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (106, 2, 'Broadcast Notification', 'Student', NULL, '2025-05-30 20:51:41', 'Broadcasted notification to 4 students');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (107, 2, 'Add Student', 'Student', NULL, '2025-06-03 20:33:26', 'Added student Joyce Attawah Elli (BIT0006726) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (108, 2, 'Archive Student', 'Student', 15, '2025-06-03 20:38:21', 'Archived student Joyce Attawah Elli (BIT0006726)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (109, 2, 'Delete Student', 'Student', 15, '2025-06-03 20:38:37', 'Deleted student Joyce Attawah Elli (BIT0006726)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (110, 2, 'Delete Student', 'Student', 5, '2025-06-03 20:38:41', 'Deleted student Joyce Elli (BIT0005626)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (111, 2, 'Add Student', 'Student', NULL, '2025-06-03 20:40:29', 'Added student Joyce Attawah Elli (BIT0005626) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (112, 2, 'Delete Student', 'Student', 16, '2025-06-03 20:42:41', 'Deleted student Joyce Attawah Elli (BIT0005626)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (113, 2, 'Add Student', 'Student', NULL, '2025-06-03 20:47:34', 'Added student Max Grip (BIT0005626) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (114, 2, 'Delete Student', 'Student', 17, '2025-06-03 20:52:22', 'Deleted student Max Grip (BIT0005626)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (115, 2, 'Add Student', 'Student', NULL, '2025-06-03 20:53:29', 'Added student Juny Hi (BIT0005226) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (116, 2, 'Delete Student', 'Student', 18, '2025-06-03 20:57:25', 'Deleted student Juny Hi (BIT0005226)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (117, 2, 'Add Student', 'Student', NULL, '2025-06-03 20:59:49', 'Added student Juni (BIT0005626) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (118, 2, 'Delete Student', 'Student', 19, '2025-06-03 21:07:52', 'Deleted student Juni (BIT0005626)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (119, 2, 'Add Student', 'Student', NULL, '2025-06-03 21:09:02', 'Added student Hii J (BIT0005626) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (120, 2, 'Delete Student', 'Student', 20, '2025-06-03 21:24:06', 'Deleted student Hii J (BIT0005626)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (121, 2, 'Add Student', 'Student', NULL, '2025-06-03 21:24:52', 'Added student Junior Owusu Fianko (BIT0005626) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (122, 2, 'Archive Student', 'Student', 21, '2025-06-03 21:28:59', 'Archived student Junior Owusu Fianko (BIT0005626)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (123, 2, 'Delete Student', 'Student', 21, '2025-06-03 21:29:05', 'Deleted student Junior Owusu Fianko (BIT0005626)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (124, 2, 'Add Student', 'Student', NULL, '2025-06-03 21:31:28', 'Added student Mensah Kofi (BIT0001326) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (125, 2, 'Add Student', 'Student', NULL, '2025-06-03 21:34:12', 'Added student Joyce Attawah Elli (BIT0008026) to Bsc Information Technology');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (126, 2, 'Add Student', 'Student', NULL, '2025-06-03 21:41:41', 'Added student Wendy Ohene Selasi (BLG0001226) to Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (127, 2, 'Add Student', 'Student', NULL, '2025-06-03 21:52:14', 'Added student Christabel Gorker (BLG0001326) to Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (128, 2, 'Add Student', 'Student', NULL, '2025-06-03 22:12:36', 'Added student Jefferson Forson (BPS0001226) to Ports and Shipping');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (129, 2, 'Add Student', 'Student', NULL, '2025-06-03 22:22:14', 'Added student Clementina Hermonu (BNS0001226) to BNS');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (130, 2, 'Add Student', 'Student', NULL, '2025-06-03 22:23:23', 'Added student Fayme Dapilah (BNS0001326) to BNS');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (131, 2, 'Add Student', 'Student', NULL, '2025-06-03 22:36:01', 'Added student Asiedu Boakye Enoch (BPS0001326) to Ports and Shipping');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (132, 2, 'Add Student', 'Student', NULL, '2025-06-03 23:12:11', 'Added student Craig Osae (BPS0001526) to Ports and Shipping');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (133, 2, 'Archive Student', 'Student', 30, '2025-06-03 23:16:37', 'Archived student Craig Osae (BPS0001526)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (134, 2, 'Delete Student', 'Student', 30, '2025-06-03 23:16:46', 'Deleted student Craig Osae (BPS0001526)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (135, 2, 'Add Student', 'Student', NULL, '2025-06-03 23:17:46', 'Added student Craig Osae Edwards (BPS0001526) to Ports and Shipping');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (136, 2, 'update', 'result', 13, '2025-06-04 00:20:46', 'Updated result for Jefferson Forson in BPS78: 78.0%');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (137, 2, 'create', 'result', 14, '2025-06-04 02:15:58', 'Created result for Asiedu Boakye Enoch in BPS78: 56.0%');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (138, 32, 'Password Changed', 'User', 32, '2025-06-04 02:19:29', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (139, 2, 'Reset Password', 'Student', 26, '2025-06-04 02:27:01', 'Reset password for Jefferson Forson (BPS0001226)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (140, 2, 'create', 'result', 15, '2025-06-04 11:18:53', 'Created result for Jefferson Forson in BHCI 344: 56.0%');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (141, 29, 'Password Changed', 'User', 29, '2025-06-04 11:27:01', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (142, 28, 'Password Changed', 'User', 28, '2025-06-04 11:36:43', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (143, 35, 'Password Changed', 'User', 35, '2025-06-04 11:50:13', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (144, 2, 'Add Course', 'Course', 17, '2025-06-04 12:15:13', 'Added course Introduction to Logistics & Supply Chain Management (LOGS101) to program Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (145, 2, 'Add Course', 'Course', 18, '2025-06-04 12:19:19', 'Added course Transport Economics (LOGS203) to program Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (146, 2, 'Add Course', 'Course', 19, '2025-06-04 12:20:55', 'Added course Warehousing and inventory Management (LOGS310) to program Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (147, 2, 'Add Course', 'Course', 20, '2025-06-04 12:22:39', 'Added course International Freight & Transport Management (LOGS405) to program Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (148, 2, 'Add Course', 'Course', 21, '2025-06-04 12:29:32', 'Added course Introduction to port Operations (BPS102) to program Ports and Shipping');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (149, 2, 'Add Course', 'Course', 22, '2025-06-04 12:30:44', 'Added course Maritime Law and Conventions (BPS205) to program Ports and Shipping');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (150, 2, 'Add Course', 'Course', 23, '2025-06-04 12:33:24', 'Added course SHIPPING MANAGEMENT & CHARTERING (BPS308) to program Ports and Shipping');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (151, 2, 'Add Course', 'Course', 24, '2025-06-04 12:35:10', 'Added course Port Planning and Development (BPS412) to program Ports and Shipping');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (152, 2, 'Broadcast Notification', 'Student', NULL, '2025-06-04 12:36:18', 'Broadcasted notification to 13 students');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (153, 2, 'Reset Password', 'Student', 23, '2025-06-04 12:39:00', 'Reset password for Joyce Attawah Elli (BIT0008026)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (154, 30, 'Password Changed', 'User', 30, '2025-06-04 12:42:43', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (155, 31, 'Password Changed', 'User', 31, '2025-06-04 12:45:40', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (156, 31, 'Password Changed', 'User', 31, '2025-06-04 12:45:40', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (157, 37, 'Password Changed', 'User', 37, '2025-06-04 12:47:40', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (158, 34, 'Password Changed', 'User', 34, '2025-06-04 12:50:46', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (159, 33, 'Password Changed', 'User', 33, '2025-06-04 12:54:48', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (160, 2, 'Add Student', 'Student', NULL, '2025-06-04 16:27:16', 'Added student Abena Shira (BNS0001726) to BNS');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (161, 2, 'Add Student', 'Student', NULL, '2025-06-04 16:29:28', 'Added student Tracy Abena Seyram (BPS0001726) to Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (162, 38, 'Password Changed', 'User', 38, '2025-06-04 16:31:04', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (163, 2, 'Edit Student', 'Student', 33, '2025-06-04 16:34:12', 'Edited student Tracy Abena Seyram (BPS0001726)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (164, 2, 'Add Student', 'Student', NULL, '2025-06-04 16:36:01', 'Added student Issa Bella (BLG0001726) to Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (165, 2, 'Add Student', 'Student', NULL, '2025-06-04 17:08:55', 'Added student Grace Maame Asor (BNS0002026) to BNS');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (166, 2, 'Delete Student', 'Student', 34, '2025-06-04 17:09:48', 'Deleted student Issa Bella (BLG0001726)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (167, 2, 'Add Student', 'Student', NULL, '2025-06-04 17:11:57', 'Added student Isabella Pinto (BLG0001726) to Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (168, 42, 'Password Changed', 'User', 42, '2025-06-04 17:15:03', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (169, 41, 'Password Changed', 'User', 41, '2025-06-04 17:22:23', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (170, 39, 'Password Changed', 'User', 39, '2025-06-04 21:46:14', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (171, 2, 'Add Student', 'Student', NULL, '2025-06-04 22:39:16', 'Added student Gatsey Prince Kofi (BNS0002126) to BNS');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (172, 43, 'Password Changed', 'User', 43, '2025-06-04 23:09:40', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (173, 2, 'Add Student', 'Student', NULL, '2025-06-04 23:21:39', 'Added student Jlekan Jartey (BLG0002026) to Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (174, 2, 'Archive Student', 'Student', 38, '2025-06-05 00:29:56', 'Archived student Jlekan Jartey (BLG0002026)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (175, 2, 'Delete Student', 'Student', 38, '2025-06-05 00:30:20', 'Deleted student Jlekan Jartey (BLG0002026)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (176, 2, 'Add Student', 'Student', NULL, '2025-06-05 00:31:56', 'Added student Jlekan Jartey (BLG0002026) to Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (177, 2, 'Archive Student', 'Student', 39, '2025-06-05 00:41:24', 'Archived student Jlekan Jartey (BLG0002026)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (178, 2, 'Add Student', 'Student', NULL, '2025-06-05 00:47:34', 'Added student Jlekan Jartey (BLG0002026) to Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (179, 2, 'Archive Student', 'Student', 40, '2025-06-05 00:49:10', 'Archived student Jlekan Jartey (BLG0002026)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (180, 2, 'Delete Student', 'Student', 40, '2025-06-05 00:49:17', 'Deleted student Jlekan Jartey (BLG0002026)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (181, 2, 'Add Student', 'Student', NULL, '2025-06-05 00:50:00', 'Added student Jlekan Jartey (BLG0002026) to Logistics');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (182, 47, 'Password Changed', 'User', 47, '2025-06-05 00:55:28', 'User changed their password on first login');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (183, 2, 'Edit Course', 'Course', 16, '2025-06-05 09:11:42', 'Edited course Introduction To Computer Science (CSC101)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (184, 2, 'Edit Course', 'Course', 13, '2025-06-05 09:12:03', 'Edited course Human Computer Interaction (BHCI 344)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (185, 2, 'Edit Course', 'Course', 12, '2025-06-05 09:12:14', 'Edited course RESEARCH METHODS (BINT 307)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (186, 2, 'Edit Course', 'Course', 11, '2025-06-05 09:12:25', 'Edited course DATA COMMUNICATION & COMPUTER NETWORKS II (BINT 306)');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (187, 2, 'Add Student', 'Student', NULL, '2025-06-05 12:05:14', 'Added student Mr Francis (BPS0009026) to Ports and Shipping');
INSERT INTO `audit_logs` (`id, admin_id, action, target_type, target_id, timestamp, details`) VALUES (188, 48, 'Password Changed', 'User', 48, '2025-06-05 12:09:35', 'User changed their password on first login');


--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `credit_hours` int NOT NULL,
  `description` text,
  `level` int DEFAULT NULL,
  `semester` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (9, 'BINT 302', 'IT PROJECT MANAGEMENT', 3, NULL, NULL, NULL);
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (7, 'BPS78', 'Logical Thinking', 3, NULL, NULL, NULL);
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (8, 'BIT0067', 'Python programming', 3, NULL, NULL, NULL);
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (10, 'BINT 304', 'DATABASE SYSTEMS II', 3, NULL, NULL, NULL);
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (11, 'BINT 306', 'DATA COMMUNICATION & COMPUTER NETWORKS II', 3, '', 100, '2');
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (12, 'BINT 307', 'RESEARCH METHODS', 3, '', 100, '2');
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (13, 'BHCI 344', 'Human Computer Interaction', 3, '', 100, '2');
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (17, 'LOGS101', 'Introduction to Logistics & Supply Chain Management', 3, 'Covers basic logistics principles, supply chain components,inventory control andtransportation.', 100, '1');
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (16, 'CSC101', 'Introduction To Computer Science', 3, 'Good course', 100, '2');
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (18, 'LOGS203', 'Transport Economics', 3, 'Focuses on economic analysis of transportation', 100, '1');
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (19, 'LOGS310', 'Warehousing and inventory Management', 2, 'Teaches Warehouse operations', 100, '2');
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (20, 'LOGS405', 'International Freight & Transport Management', 2, 'Examines the documentation of international frieght movement', 100, '2');
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (21, 'BPS102', 'Introduction to port Operations', 4, 'Covers the basic structure and functions of ports, port types, terminal operations, cargo handling and port logistics systems', 100, '1');
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (22, 'BPS205', 'Maritime Law and Conventions', 3, 'Introduces students to the maritime Law', 100, '1');
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (23, 'BPS308', 'SHIPPING MANAGEMENT & CHARTERING', 2, 'Examines commercial shipping operations', 100, '2');
INSERT INTO `courses` (`id, code, title, credit_hours, description, level, semester`) VALUES (24, 'BPS412', 'Port Planning and Development', 2, 'Focus on strategic port development', 100, '2');


--
-- Table structure for table `levels`
--

CREATE TABLE `levels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `levels`
--

INSERT INTO `levels` (`id, name, description, archived`) VALUES (1, 'Level 100', 'First Year Students', 0);
INSERT INTO `levels` (`id, name, description, archived`) VALUES (2, 'Level 200', 'Second Year Students', 0);
INSERT INTO `levels` (`id, name, description, archived`) VALUES (3, 'Level 300', 'Third Year Students', 0);
INSERT INTO `levels` (`id, name, description, archived`) VALUES (4, 'Level 400', 'Fourth Year Students', 0);


--
-- Table structure for table `login_history`
--

CREATE TABLE `login_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=186 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `login_history`
--

INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (1, 1, '2025-05-09 03:02:35', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (2, 1, '2025-05-09 04:42:09', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (3, 4, '2025-05-09 04:50:04', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (4, 2, '2025-05-09 04:50:32', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (5, 4, '2025-05-09 04:56:12', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (6, 2, '2025-05-09 05:02:06', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (7, 1, '2025-05-09 05:26:27', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (8, 2, '2025-05-09 05:32:41', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (9, 1, '2025-05-09 05:47:14', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (10, 2, '2025-05-09 05:57:00', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (11, 1, '2025-05-09 05:59:56', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (12, 2, '2025-05-09 06:10:00', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (13, 2, '2025-05-09 06:10:06', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (14, 2, '2025-05-09 06:11:58', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (15, 1, '2025-05-09 06:12:17', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (16, 2, '2025-05-09 06:12:47', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (17, 1, '2025-05-09 06:13:35', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (18, 2, '2025-05-09 06:43:27', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (19, 2, '2025-05-09 06:44:55', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (20, 3, '2025-05-09 06:47:29', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (21, 2, '2025-05-09 06:50:26', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (22, 1, '2025-05-11 04:57:55', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (23, 2, '2025-05-11 04:58:40', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (24, 1, '2025-05-11 07:16:07', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (25, 2, '2025-05-11 07:17:46', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (26, 1, '2025-05-11 08:51:54', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (27, 2, '2025-05-11 08:52:19', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (28, 1, '2025-05-11 08:56:08', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (29, 2, '2025-05-11 08:56:45', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (30, 1, '2025-05-15 11:55:23', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (31, 2, '2025-05-15 11:56:34', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (32, 5, '2025-05-15 12:52:34', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (33, 2, '2025-05-15 12:53:43', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (34, 1, '2025-05-15 16:57:18', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (35, 4, '2025-05-15 16:58:13', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (36, 1, '2025-05-15 17:13:16', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (37, 2, '2025-05-15 17:21:09', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (38, 1, '2025-05-15 17:25:17', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (39, 2, '2025-05-15 17:40:14', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (40, 1, '2025-05-15 17:45:16', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (41, 2, '2025-05-15 17:47:03', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (42, 1, '2025-05-15 17:59:36', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (43, 1, '2025-05-15 18:06:06', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (44, 2, '2025-05-15 18:06:47', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (45, 5, '2025-05-15 18:07:59', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (46, 2, '2025-05-15 18:08:36', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (47, 1, '2025-05-15 21:01:41', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (48, 2, '2025-05-15 21:26:30', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (49, 1, '2025-05-15 21:38:20', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (50, 2, '2025-05-15 21:43:50', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (51, 2, '2025-05-15 22:05:31', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (52, 1, '2025-05-15 22:21:14', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (53, 1, '2025-05-15 22:28:25', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (54, 2, '2025-05-15 22:31:12', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (55, 1, '2025-05-16 00:53:30', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (56, 2, '2025-05-16 01:17:08', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (57, 4, '2025-05-16 16:54:18', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (58, 2, '2025-05-16 16:54:57', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (59, 4, '2025-05-16 16:55:55', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (60, 2, '2025-05-16 16:57:51', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (61, 2, '2025-05-17 15:36:39', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (62, 1, '2025-05-17 18:07:46', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (63, 2, '2025-05-17 18:17:05', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (64, 1, '2025-05-17 18:17:38', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (65, 2, '2025-05-17 18:31:08', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (66, 2, '2025-05-17 20:29:38', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (67, 1, '2025-05-17 21:33:36', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (68, 2, '2025-05-17 22:53:26', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (69, 2, '2025-05-20 15:29:21', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (70, 1, '2025-05-20 15:30:28', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (71, 2, '2025-05-27 22:44:02', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (72, 1, '2025-05-27 22:47:51', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (73, 2, '2025-05-27 22:48:55', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (74, 1, '2025-05-27 22:49:40', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (75, 2, '2025-05-27 22:54:24', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (76, 1, '2025-05-27 23:00:02', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (77, 2, '2025-05-27 23:04:10', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (78, 1, '2025-05-27 23:04:41', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (79, 2, '2025-05-27 23:10:31', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (80, 1, '2025-05-27 23:28:04', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (81, 1, '2025-05-27 23:57:03', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (82, 2, '2025-05-28 00:02:13', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (83, 1, '2025-05-28 00:13:33', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (84, 2, '2025-05-28 01:31:02', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (85, 2, '2025-05-28 03:02:52', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (86, 1, '2025-05-28 03:03:10', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (87, 2, '2025-05-28 03:04:31', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (88, 1, '2025-05-28 03:05:01', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (89, 2, '2025-05-28 03:07:05', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (90, 1, '2025-05-28 03:57:57', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (91, 1, '2025-05-28 10:13:10', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (92, 2, '2025-05-28 10:18:42', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (93, 1, '2025-05-28 10:44:49', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (94, 1, '2025-05-28 11:12:28', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (95, 1, '2025-05-28 11:15:58', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (96, 2, '2025-05-28 21:24:28', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (97, 2, '2025-05-28 21:45:21', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (98, 1, '2025-05-28 22:37:56', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (99, 2, '2025-05-28 22:38:18', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (100, 2, '2025-05-28 23:03:47', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (101, 2, '2025-05-29 00:17:39', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (102, 1, '2025-05-29 02:13:10', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (103, 1, '2025-05-29 02:13:49', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (104, 2, '2025-05-29 02:16:00', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (105, 2, '2025-05-29 03:36:09', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (106, 1, '2025-05-29 10:10:59', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (107, 2, '2025-05-29 10:12:48', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (108, 2, '2025-05-29 17:27:13', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (109, 20, '2025-05-29 19:54:18', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (110, 2, '2025-05-29 19:55:43', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (111, 2, '2025-05-29 20:00:29', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (112, 20, '2025-05-29 20:01:26', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (113, 2, '2025-05-29 20:02:31', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (114, 1, '2025-05-29 20:19:25', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (115, 2, '2025-05-29 20:19:50', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (116, 20, '2025-05-29 20:24:48', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (117, 2, '2025-05-29 20:35:33', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (118, 20, '2025-05-29 21:03:48', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (119, 2, '2025-05-29 21:09:47', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (120, 1, '2025-05-29 21:10:39', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (121, 20, '2025-05-29 21:11:16', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (122, 2, '2025-05-29 21:11:50', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (123, 1, '2025-05-30 00:28:54', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (124, 20, '2025-05-30 00:29:59', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (125, 2, '2025-05-30 01:25:07', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (126, 2, '2025-05-30 01:44:18', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (127, 2, '2025-05-30 01:57:35', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (128, 2, '2025-05-30 13:38:32', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (129, 20, '2025-05-30 15:07:33', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (130, 4, '2025-05-30 15:08:58', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (131, 2, '2025-05-30 15:09:16', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (132, 2, '2025-05-30 23:05:09', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (133, 1, '2025-05-31 13:52:12', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (134, 2, '2025-06-03 20:31:45', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (135, 32, '2025-06-04 02:17:59', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (136, 1, '2025-06-04 02:20:24', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (137, 2, '2025-06-04 02:25:05', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (138, 32, '2025-06-04 02:27:22', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (139, 2, '2025-06-04 11:17:01', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (140, 32, '2025-06-04 11:19:13', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (141, 29, '2025-06-04 11:25:31', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (142, 28, '2025-06-04 11:36:01', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (143, 28, '2025-06-04 11:37:02', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (144, 32, '2025-06-04 11:38:23', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (145, 2, '2025-06-04 11:47:40', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (146, 35, '2025-06-04 11:49:29', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (147, 32, '2025-06-04 11:55:55', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (148, 28, '2025-06-04 11:57:29', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (149, 2, '2025-06-04 12:02:19', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (150, 28, '2025-06-04 12:36:50', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (151, 32, '2025-06-04 12:37:27', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (152, 35, '2025-06-04 12:37:52', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (153, 2, '2025-06-04 12:38:14', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (154, 29, '2025-06-04 12:39:17', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (155, 30, '2025-06-04 12:42:02', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (156, 31, '2025-06-04 12:44:08', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (157, 31, '2025-06-04 12:46:03', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (158, 37, '2025-06-04 12:46:59', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (159, 34, '2025-06-04 12:49:26', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (160, 33, '2025-06-04 12:54:03', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (161, 34, '2025-06-04 12:57:53', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (162, 31, '2025-06-04 13:00:06', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (163, 30, '2025-06-04 13:01:28', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (164, 2, '2025-06-04 16:25:18', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (165, 38, '2025-06-04 16:30:29', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (166, 2, '2025-06-04 16:32:28', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (167, 42, '2025-06-04 17:14:22', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (168, 41, '2025-06-04 17:21:41', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (169, 2, '2025-06-04 20:39:26', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (170, 35, '2025-06-04 20:54:26', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (171, 39, '2025-06-04 21:43:57', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (172, 2, '2025-06-04 22:24:43', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (173, 32, '2025-06-04 22:25:08', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (174, 2, '2025-06-04 22:36:45', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (175, 43, '2025-06-04 23:08:37', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (176, 2, '2025-06-04 23:10:19', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (177, 2, '2025-06-05 00:33:24', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (178, 46, '2025-06-05 00:47:59', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (179, 2, '2025-06-05 00:48:40', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (180, 47, '2025-06-05 00:53:29', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (181, 2, '2025-06-05 01:09:01', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (182, 29, '2025-06-05 09:24:11', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (183, 2, '2025-06-05 11:58:44', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (184, 48, '2025-06-05 12:07:05', '127.0.0.1');
INSERT INTO `login_history` (`id, user_id, timestamp, ip_address`) VALUES (185, 2, '2025-06-05 12:10:18', '127.0.0.1');


--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (1, 1, 'Good morning students, Exams will be held tomorrow at 9:00 am', 1, '2025-05-09 05:13:41');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (2, 3, 'Good morning students, Exams will be held tomorrow at 9:00 am', 0, '2025-05-09 05:13:41');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (3, 4, 'Good morning students, Exams will be held tomorrow at 9:00 am', 0, '2025-05-09 05:13:41');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (4, 1, 'Also make sure you done cheat', 1, '2025-05-09 05:22:22');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (5, 3, 'Also make sure you done cheat', 0, '2025-05-09 05:22:22');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (6, 4, 'Also make sure you done cheat', 0, '2025-05-09 05:22:22');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (7, 1, 'Learn', 1, '2025-05-09 05:25:57');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (8, 3, 'Learn', 0, '2025-05-09 05:25:57');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (9, 4, 'Learn', 0, '2025-05-09 05:25:57');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (10, 5, 'Hello', 0, '2025-05-15 12:54:31');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (11, 1, 'hello max', 1, '2025-05-28 03:04:45');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (12, 1, 'yall becareful', 1, '2025-05-28 03:45:15');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (13, 4, 'yall becareful', 0, '2025-05-28 03:45:15');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (14, 5, 'yall becareful', 0, '2025-05-28 03:45:15');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (15, 1, 'hi', 1, '2025-05-28 03:53:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (16, 4, 'hi', 0, '2025-05-28 03:53:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (17, 5, 'hi', 0, '2025-05-28 03:53:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (18, 1, 'yoo', 1, '2025-05-28 03:57:00');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (19, 1, 'hi', 1, '2025-05-28 10:42:15');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (20, 1, 'To all  student\'s please make sure you have your QR codes printed', 0, '2025-05-30 20:51:41');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (21, 4, 'To all  student\'s please make sure you have your QR codes printed', 0, '2025-05-30 20:51:41');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (22, 5, 'To all  student\'s please make sure you have your QR codes printed', 0, '2025-05-30 20:51:41');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (23, 20, 'To all  student\'s please make sure you have your QR codes printed', 0, '2025-05-30 20:51:41');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (24, 1, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 0, '2025-06-04 12:36:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (25, 4, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 0, '2025-06-04 12:36:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (26, 5, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 0, '2025-06-04 12:36:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (27, 29, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 1, '2025-06-04 12:36:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (28, 20, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 0, '2025-06-04 12:36:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (29, 28, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 1, '2025-06-04 12:36:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (30, 30, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 0, '2025-06-04 12:36:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (31, 31, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 0, '2025-06-04 12:36:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (32, 32, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 0, '2025-06-04 12:36:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (33, 33, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 0, '2025-06-04 12:36:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (34, 34, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 0, '2025-06-04 12:36:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (35, 35, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 0, '2025-06-04 12:36:18');
INSERT INTO `notifications` (`id, user_id, message, is_read, created_at`) VALUES (36, 37, 'Good morning to you all, tomorrow is a holiday so the exams have been postponed to next week Tuesday', 0, '2025-06-04 12:36:18');


--
-- Table structure for table `program_courses`
--

CREATE TABLE `program_courses` (
  `program_id` int NOT NULL,
  `course_id` int NOT NULL,
  PRIMARY KEY (`program_id`,`course_id`),
  KEY `course_id` (`course_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `program_courses`
--

INSERT INTO `program_courses` (`program_id, course_id`) VALUES (1, 8);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (1, 9);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (1, 10);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (1, 11);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (1, 12);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (1, 13);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (1, 16);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (2, 7);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (2, 9);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (2, 22);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (3, 7);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (3, 13);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (3, 21);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (3, 22);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (3, 23);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (3, 24);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (4, 17);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (4, 18);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (4, 19);
INSERT INTO `program_courses` (`program_id, course_id`) VALUES (4, 20);


--
-- Table structure for table `programs`
--

CREATE TABLE `programs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `archived` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`id, name, description, archived`) VALUES (1, 'Bsc Information Technology', 'Info Techs', 0);
INSERT INTO `programs` (`id, name, description, archived`) VALUES (2, 'BNS', 'Marine', 0);
INSERT INTO `programs` (`id, name, description, archived`) VALUES (3, 'Ports and Shipping', 'Sea Fairing', 0);
INSERT INTO `programs` (`id, name, description, archived`) VALUES (4, 'Logistics', 'Transportation', 0);


--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `course_id` int NOT NULL,
  `score` decimal(5,2) NOT NULL,
  `grade` varchar(2) NOT NULL,
  `semester` varchar(20) NOT NULL,
  `academic_year` varchar(20) NOT NULL,
  `remarks` text,
  `uploaded_by` int NOT NULL,
  `uploaded_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `student_level_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `student_id` (`student_id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `fk_student_level` (`student_level_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (1, 1, 8, '78.00', 'A-', '1', '2024-2025', 'Good', 2, '2025-05-28 00:11:13', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (2, 1, 9, '87.00', 'A', '1', '2025-2026', 'Good', 2, '2025-05-28 00:11:33', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (3, 1, 10, '56.00', 'C+', '2', '2025-2026', 'Bad', 2, '2025-05-28 00:11:57', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (4, 1, 11, '70.00', 'A-', '2', '2025-2026', 'Average', 2, '2025-05-28 00:12:24', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (5, 1, 12, '89.00', 'A', '1', '2025-2026', 'Great', 2, '2025-05-28 00:13:02', 2);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (6, 14, 8, '78.00', 'A-', '1', '2024-2025', 'Good', 2, '2025-05-29 19:56:51', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (7, 14, 9, '89.00', 'A', '2', '2024-2025', 'Good', 2, '2025-05-29 19:57:31', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (8, 14, 10, '89.00', 'A', '1', '2025-2026', 'Good', 2, '2025-05-29 19:59:19', 2);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (9, 14, 13, '85.00', 'A', 'First', '2024/2025', 'Excellent performance', 2, '2025-05-29 21:03:03', 200);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (10, 1, 13, '72.00', 'A-', 'First', '2024/2025', 'Good work', 2, '2025-05-29 21:03:03', 200);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (11, 14, 13, '85.00', 'A', '1', '2024/2025', 'Excellent performance', 2, '2025-05-29 21:10:04', 2);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (12, 1, 13, '72.00', 'A-', '1', '2024/2025', 'Good work', 2, '2025-05-29 21:10:04', 2);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (13, 26, 7, '78.00', 'A-', '1', '2024-2025', 'good', 2, '2025-06-04 00:18:20', NULL);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (14, 29, 7, '56.00', 'C+', '1', '2024-2025', 'good', 2, '2025-06-04 02:15:58', NULL);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (15, 26, 13, '56.00', 'C+', '2', '2025-2026', 'MM bad', 2, '2025-06-04 11:18:53', NULL);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (16, 23, 9, '85.00', 'A', '1', '2024/2025', 'Excellent performance', 2, '2025-06-05 09:22:56', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (17, 23, 7, '72.00', 'A-', '1', '2024/2025', 'Good work', 2, '2025-06-05 09:22:56', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (18, 23, 11, '56.00', 'C+', '2', '2025/2026', 'Bad', 2, '2025-06-05 09:22:56', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (19, 23, 12, '63.00', 'B', '2', '2025/2026', 'Average', 2, '2025-06-05 09:22:56', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (20, 22, 9, '67.00', 'B+', '1', '2024/2025', 'Average', 2, '2025-06-05 09:22:56', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (21, 22, 7, '49.00', 'D', '1', '2024/2025', 'Average', 2, '2025-06-05 09:22:56', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (22, 22, 11, '52.00', 'C', '2', '2025/2026', 'Average', 2, '2025-06-05 09:22:56', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (23, 22, 12, '94.00', 'A', '2', '2025/2026', 'Average', 2, '2025-06-05 09:22:57', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (24, 28, 22, '82.00', 'A', '1', '2024/2025', 'Good work', 2, '2025-06-05 09:22:57', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (25, 28, 7, '76.00', 'A-', '1', '2024/2025', 'Good work', 2, '2025-06-05 09:22:57', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (26, 31, 7, '12.00', 'F', '1', '2024/2025', 'Bad', 2, '2025-06-05 09:22:57', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (27, 31, 13, '78.00', 'A-', '2', '2025/2026', 'Good work', 2, '2025-06-05 09:22:57', 1);
INSERT INTO `results` (`id, student_id, course_id, score, grade, semester, academic_year, remarks, uploaded_by, uploaded_at, student_level_id`) VALUES (28, 31, 24, '55.00', 'C+', '2', '2025/2026', 'Good work', 2, '2025-06-05 09:22:57', 1);


--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `index_number` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `program_id` int NOT NULL,
  `level` varchar(20) NOT NULL,
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `level_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `index_number` (`index_number`),
  UNIQUE KEY `idx_student_email` (`email`),
  KEY `idx_program_id` (`program_id`),
  KEY `fk_level_id` (`level_id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (1, 1, 'BIT0001927', 'Max Grip', NULL, 1, '200', 0, 2);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (3, 4, 'BPS0001827', 'Micheal Ohene Asante', NULL, 1, '400', 0, 2);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (4, 5, 'BIT0001227', 'Agyenkwa Arthur ', NULL, 1, '100', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (23, 29, 'BIT0008026', 'Joyce Attawah Elli', NULL, 1, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (14, 20, 'BIT0004526', 'Maryln Grip', NULL, 1, '', 0, 2);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (22, 28, 'BIT0001326', 'Mensah Kofi', NULL, 1, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (24, 30, 'BLG0001226', 'Wendy Ohene Selasi', NULL, 4, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (25, 31, 'BLG0001326', 'Christabel Gorker', NULL, 4, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (26, 32, 'BPS0001226', 'Jefferson Forson', NULL, 3, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (27, 33, 'BNS0001226', 'Clementina Hermonu', NULL, 2, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (28, 34, 'BNS0001326', 'Fayme Dapilah', NULL, 2, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (29, 35, 'BPS0001326', 'Asiedu Boakye Enoch', NULL, 3, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (31, 37, 'BPS0001526', 'Craig Osae Edwards', NULL, 3, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (32, 38, 'BNS0001726', 'Abena Shira', NULL, 2, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (33, 39, 'BPS0001726', 'Tracy Abena Seyram', NULL, 3, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (36, 42, 'BLG0001726', 'Isabella Pinto', NULL, 4, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (35, 41, 'BNS0002026', 'Grace Maame Asor', NULL, 2, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (37, 43, 'BNS0002126', 'Gatsey Prince Kofi', NULL, 2, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (42, 48, 'BPS0009026', 'Mr Francis', NULL, 3, '', 0, 1);
INSERT INTO `students` (`id, user_id, index_number, full_name, email, program_id, level, archived, level_id`) VALUES (41, 47, 'BLG0002026', 'Jlekan Jartey', NULL, 4, '', 0, 1);


--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(128) NOT NULL,
  `user_type` enum('admin','student') NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `first_login` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Flag to indicate if user needs to change password on first login',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (1, 'max', 'maxgrip500@gmail.com', 'pbkdf2:sha256:1000000$7PkqW6s142WatTxK$0697ee2cbaa627967b2b80589394063736a35d9941bed59ab2ab5df57a7a4ac9', 'student', '2025-05-08 23:41:45', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (2, 'admin', 'admin@example.com', 'pbkdf2:sha256:1000000$UejAFBDMqfgWixqC$2c8362ea040698b7244f3b52b0b08706c581b7ad8b78df751d1eb367e3e91d25', 'admin', '2025-05-09 00:01:33', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (3, 'BNS002', 'BNS002@student.portal', 'pbkdf2:sha256:1000000$Dy9BaNUZXKQKnXrh$026300fd745789cb04a9c2246d25e4c5d8c80a3c377a78a93890def79ece8140', 'student', '2025-05-09 01:31:25', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (4, 'Micheal', 'asantemichael044@gmail.com', 'pbkdf2:sha256:1000000$yMQZRAH71zRK7nsk$d0fda459391c171c5d77b94b267aaac277229d85e27b4e37bb4319de499dd4d0', 'student', '2025-05-09 04:49:38', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (5, 'agyenkwa', 'agyenkwa@st.rmu.edu.gh', 'pbkdf2:sha256:1000000$4bH2bwcIePof0Yuo$0afaed5db05761e4d06b22d4e04192f3351042db86c609650d9a972bb10c6778', 'student', '2025-05-15 12:52:07', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (29, 'joyce', 'elliattawah23@gmail.com', 'pbkdf2:sha256:1000000$UC1OBHa7gSzmZoSi$4fe7662915ecdac66da5b2a8b74f8240f2b27579d6f06d2b44dea7f3df51d795', 'student', '2025-06-03 21:34:12', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (20, 'marylyngrip', 'marylyngrip@gmail.com', 'pbkdf2:sha256:1000000$1Hn6L3glmFBVbu60$827d88cd65ab7e0302dbe8fa16dbb1b9648636b7a4969a13be1b95ff81259df7', 'student', '2025-05-29 19:53:18', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (27, 'junior', 'owusujunior625@gmail.com', 'pbkdf2:sha256:1000000$wFzrZkbF5b0HeyQZ$88d283c571b3561090fc2acf66efa52e2f1d9ad78110835bd0fe8459e977bf4f', 'student', '2025-06-03 21:24:52', 1);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (28, 'kofi', 'codexcoder082@gmail.com', 'pbkdf2:sha256:1000000$ilTrPF6ipeZOoCEW$c5b13bfffa95b0e3a92a23ba9233dc94ba495dc40b704d156e41c5e37da92c71', 'student', '2025-06-03 21:31:28', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (30, 'wendy', 'wendyohene426@gmail.com', 'pbkdf2:sha256:1000000$QIMhfYjdsFni6g9G$c439e667ac73a4f4a747b1f9cf5faaf5e49f0ff65755afee8fbfd0d197b6e6a1', 'student', '2025-06-03 21:41:41', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (31, 'christabel', 'christabel.gorker@st.rmu.edu.gh', 'pbkdf2:sha256:1000000$chs1BCkODQRQp9F5$011587f1125c8301285a47751affa15fb4ad43f546af149f037e769c03c0b637', 'student', '2025-06-03 21:52:14', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (32, 'jeff', 'jeffersonforson24@gmail.com', 'pbkdf2:sha256:1000000$AXAnTPhbqasKrvph$3fb5911453ee5353d84f37432aded9b0e44c05313b95171eb6ed6f5199041ad2', 'student', '2025-06-03 22:12:36', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (33, 'clementina', 'hermonuclementina@gmail.com', 'pbkdf2:sha256:1000000$UJ4FReEgKccFrJkV$721f24939aaacdf5eb41259f41c2b4bab8de86ee894dcba93add927835ab2b86', 'student', '2025-06-03 22:22:14', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (34, 'fayme', 'official.fayme08@gmail.com', 'pbkdf2:sha256:1000000$ztXDI0rvvR1gpDni$99a2604435769be828b89cdc5781b764ca6e4b5c813d3259ae41a5ca1b6c41ae', 'student', '2025-06-03 22:23:23', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (35, 'enoch', 'asieduboakye222@gmail.com', 'pbkdf2:sha256:1000000$HM9wwFqd24jaxJIo$209fc75aa154201b51a8bdefad84efada3f632c31d6f50e8cbd14de8211e8256', 'student', '2025-06-03 22:36:01', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (37, 'craig', 'craigosae1@gmail.com', 'pbkdf2:sha256:1000000$KzbTvLpKlm08o8NN$b773e0998c57c7e2a68a1f0dbd479590ef64d1a2fd94ae8a1f9afe0909582ad0', 'student', '2025-06-03 23:17:46', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (38, 'shira', 'shiraharley027@gmail.com', 'pbkdf2:sha256:1000000$TUJNuyw1Z7AWkqEX$7e9c2a71eaed598eabd3db9ed4eb46bb7e6ce7d76c20d4ceb78d5f6cc0ff7a60', 'student', '2025-06-04 16:27:16', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (39, 'seyram', 'tracyseyfert11@gmail.com', 'pbkdf2:sha256:1000000$AjM5CVcpF5WIjIC0$d6f10ee987126f3b0d116fe101ca56e92ed3f2d7b3fdb0fecfadbe2917314b05', 'student', '2025-06-04 16:29:28', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (42, 'isabella', 'isabella.pinto@st.rmu.edu.gh', 'pbkdf2:sha256:1000000$qKuTEN25p8Pki5jc$8c7ac883944980e83e1a603d7957b835e186c7643dc9486cd6b51aa61ae46f86', 'student', '2025-06-04 17:11:57', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (41, 'grace', 'grace.asor1oti@gmail.com', 'pbkdf2:sha256:1000000$fIELWzbcRX7odAxd$3e1c5a0d7fcf47eaddae6aedd19cb9c1df45355dd93db49ff4994eabd1640a4a', 'student', '2025-06-04 17:08:55', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (43, 'selorm', 'princegatsey067@gmail.com', 'pbkdf2:sha256:1000000$QU1jE30Ms8NSPR6M$eb3b704d26a267fb0bec327887c562619b1e45e6ac33feda5042e2ddfd39ffe0', 'student', '2025-06-04 22:39:16', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (47, 'jlekan', 'jlekanjartehj@gmail.com', 'pbkdf2:sha256:1000000$Wpeyqol9v2Q7sN0l$c65c9f5de9b804659aed95fb532ae679c444b525b2948a5a4f411e8580095d82', 'student', '2025-06-05 00:50:00', 0);
INSERT INTO `users` (`id, username, email, password_hash, user_type, created_at, first_login`) VALUES (48, 'francis', 'y.m.ratty7@gmail.com', 'pbkdf2:sha256:1000000$YUUGkpykHjDrBbe5$cfb0ec25c0ab4a5749bbefc244150848cc868fea5b98c35f25c6b54ceddee79d', 'student', '2025-06-05 12:05:14', 0);


-- Dump completed on 2025-06-05 12:12:01
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
